const settings = {
  packname: 'Scotty-C',
  author: 'Scotty-C',
  botName: "Scotty-C",
  botOwner: 'Scotty', // Your name
  ownerNumber: '263788114185', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'NrSjG6var2uiuSYDm0xTqCX0xcFgGj4s',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "1.0.0",
  updateZipUrl: "https://github.com/Garo028/Scotty-C/archive/refs/heads/main.zip",
};

module.exports = settings;
